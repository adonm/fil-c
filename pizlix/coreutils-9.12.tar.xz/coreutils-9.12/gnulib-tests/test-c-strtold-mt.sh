#!/bin/sh

: "${LOCALE_FR=fr_FR}"
: "${LOCALE_FR_UTF8=fr_FR.UTF-8}"

if test $LOCALE_FR = none && test $LOCALE_FR_UTF8 = none; then
  if test -f /usr/bin/localedef; then
    echo "Skipping test: no locale for testing is installed"
  else
    echo "Skipping test: no locale for testing is supported"
  fi
  exit 77
fi

if $LC_NUMERIC_IMPLEMENTED; then
  :
else
  echo "Skipping test: LC_NUMERIC category of locales is not implemented"
  exit 77
fi

no_fail_status=0

if test $LOCALE_FR != none; then
  LC_ALL=$LOCALE_FR      ${CHECKER} ./test-c-strtold-mt${EXEEXT}
  case $? in
    0) ;;
    77) no_fail_status=77 ;;
    *) exit 1 ;;
  esac
fi

if test $LOCALE_FR_UTF8 != none; then
  LC_ALL=$LOCALE_FR_UTF8 ${CHECKER} ./test-c-strtold-mt${EXEEXT}
  case $? in
    0) ;;
    77) no_fail_status=77 ;;
    *) exit 1 ;;
  esac
fi

exit 0
